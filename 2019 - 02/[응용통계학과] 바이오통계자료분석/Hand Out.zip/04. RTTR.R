
# 2x2 Cross Over Design

# Original Data
original_data <- read.csv("../RTTR.csv", header = T)
head(original_data)

# Data Transformation
library(tidyverse)
data1 <- data.frame(sub=1:18, seq = original_data[,2])
data1 <- mutate(data1, AUC = original_data$period1, period = 1)
data1 <- mutate(data1, formula = if_else(seq == 1, "R", "T"))
data2 <- data.frame(sub=1:18, seq=original_data[,2])
data2 <- mutate(data2, AUC = original_data$period2, period = 2)
data2 <- mutate(data2, formula = if_else(seq == 1, "T", "R"))

# Data Merge
long_data <- merge(data1, data2, all = T)
long_data <- select(long_data, sub, seq, formula, period, AUC)

# Long Format Data
long_data <- long_data %>% mutate(sub = as.factor(sub), seq = as.factor(seq), formula = as.factor(formula), period = as.factor(period))
str(long_data)

# Data Anaysis
library(BE)
BEdata <- with(long_data, data.frame(sub, period, formula, log(AUC)))
names(BEdata) <- c("SUBJ", "PRD", "TRT", "AUC")
BEdata$GRP <- ifelse(long_data$seq == 1, "RT", "TR")
be2x2(BEdata, Columns = c("AUC"))

